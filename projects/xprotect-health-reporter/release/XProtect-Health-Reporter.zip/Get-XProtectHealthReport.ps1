#requires -Version 5.1
<#
.SYNOPSIS
    Creates a point-in-time XProtect hardware and camera health report.

.DESCRIPTION
    Uses the official MilestonePSTools module to collect all hardware and camera
    configuration, current recorder-side status, stream information, storage
    information, and optional retention / recording statistics.

    Output is written to a timestamped folder as:
      - XProtect-Health-Report.html
      - XProtect-Camera-Status.csv
      - XProtect-Hardware-Status.csv
      - XProtect-Camera-Inventory-Full.csv
      - XProtect-Run-Summary.json

    No camera passwords are requested or exported.

.NOTES
    Run with Windows PowerShell 5.1 (powershell.exe), not PowerShell 7 (pwsh.exe).
    Recorder-side status requires TCP 7563 from the computer running this script
    to each XProtect Recording Server.
#>

[CmdletBinding()]
param(
    [Parameter()]
    [uri]$ServerAddress,

    [Parameter()]
    [pscredential]$Credential,

    [Parameter()]
    [switch]$BasicUser,

    [Parameter()]
    [switch]$SecureOnly,

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string]$ConnectionProfile = 'default',

    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string]$OutputPath = (Join-Path ([Environment]::GetFolderPath('Desktop')) 'XProtectReports'),

    [Parameter()]
    [switch]$IncludeRetentionInfo,

    [Parameter()]
    [switch]$IncludeRecordingStats,

    [Parameter()]
    [switch]$InstallModule,

    [Parameter()]
    [switch]$OpenReport
)

Set-StrictMode -Version 2.0
$ErrorActionPreference = 'Stop'

function Get-XpProperty {
    [CmdletBinding()]
    param(
        [Parameter()]
        [AllowNull()]
        $Object,

        [Parameter(Mandatory)]
        [string[]]$Name,

        [Parameter()]
        [AllowNull()]
        $Default = $null
    )

    if ($null -eq $Object) {
        return $Default
    }

    foreach ($propertyName in $Name) {
        $property = $Object.PSObject.Properties[$propertyName]
        if (($null -ne $property) -and ($null -ne $property.Value)) {
            return $property.Value
        }
    }

    return $Default
}

function ConvertTo-XpBool {
    [CmdletBinding()]
    param(
        [Parameter()]
        [AllowNull()]
        $Value
    )

    if ($null -eq $Value) {
        return $null
    }

    if ($Value -is [bool]) {
        return [bool]$Value
    }

    $parsed = $false
    if ([bool]::TryParse([string]$Value, [ref]$parsed)) {
        return $parsed
    }

    switch -Regex ([string]$Value) {
        '^(1|yes|y|on|enabled)$'  { return $true }
        '^(0|no|n|off|disabled)$' { return $false }
        default                   { return $null }
    }
}

function Get-XpKey {
    [CmdletBinding()]
    param(
        [Parameter()]
        [AllowNull()]
        $Value
    )

    if ($null -eq $Value) {
        return ''
    }

    return ([string]$Value).Trim().ToLowerInvariant()
}

function ConvertTo-XpDisplayText {
    [CmdletBinding()]
    param(
        [Parameter()]
        [AllowNull()]
        $Value
    )

    if ($null -eq $Value) {
        return ''
    }

    if ($Value -is [datetime]) {
        return $Value.ToString('yyyy-MM-dd HH:mm:ss')
    }

    if ($Value -is [bool]) {
        if ($Value) { return 'Yes' }
        return 'No'
    }

    if (($Value -is [System.Collections.IEnumerable]) -and -not ($Value -is [string])) {
        return (($Value | ForEach-Object { [string]$_ }) -join ', ')
    }

    return [string]$Value
}

function ConvertTo-XpHtmlText {
    [CmdletBinding()]
    param(
        [Parameter()]
        [AllowNull()]
        $Value
    )

    $displayValue = ConvertTo-XpDisplayText -Value $Value
    return [System.Net.WebUtility]::HtmlEncode($displayValue)
}

function Get-XpStatusSlug {
    [CmdletBinding()]
    param(
        [Parameter()]
        [AllowNull()]
        $Status
    )

    $slug = ([string]$Status).Trim().ToLowerInvariant() -replace '[^a-z0-9]+', '-'
    $slug = $slug.Trim('-')
    if ([string]::IsNullOrWhiteSpace($slug)) {
        return 'unknown'
    }
    return $slug
}

function Get-XpCameraHealth {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        $Camera
    )

    $enabled = ConvertTo-XpBool (Get-XpProperty -Object $Camera -Name @('Enabled'))
    $started = ConvertTo-XpBool (Get-XpProperty -Object $Camera -Name @('IsStarted', 'Started'))
    $overflow = ConvertTo-XpBool (Get-XpProperty -Object $Camera -Name @('IsInOverflow', 'ErrorOverflow'))
    $dbRepair = ConvertTo-XpBool (Get-XpProperty -Object $Camera -Name @('IsInDbRepair', 'DbRepairInProgress'))
    $writeError = ConvertTo-XpBool (Get-XpProperty -Object $Camera -Name @('ErrorWritingGOP', 'ErrorWritingGop'))
    $notLicensed = ConvertTo-XpBool (Get-XpProperty -Object $Camera -Name @('ErrorNotLicensed'))
    $noConnection = ConvertTo-XpBool (Get-XpProperty -Object $Camera -Name @('ErrorNoConnection'))
    $genericError = ConvertTo-XpBool (Get-XpProperty -Object $Camera -Name @('Error'))
    $statusTime = Get-XpProperty -Object $Camera -Name @('StatusTime', 'Time')
    $eventState = [string](Get-XpProperty -Object $Camera -Name @('State') -Default '')

    if ($enabled -eq $false) {
        return [pscustomobject][ordered]@{
            Status   = 'DISABLED'
            Severity = 900
            Online   = 'N/A'
            Issue    = 'Camera or parent hardware is disabled in XProtect'
        }
    }

    if ($notLicensed -eq $true) {
        return [pscustomobject][ordered]@{
            Status   = 'UNLICENSED'
            Severity = 10
            Online   = 'No'
            Issue    = 'Device is not licensed or its grace period has expired'
        }
    }

    if ($noConnection -eq $true) {
        return [pscustomobject][ordered]@{
            Status   = 'OFFLINE'
            Severity = 20
            Online   = 'No'
            Issue    = 'Recording Server cannot receive the camera stream'
        }
    }

    if (($writeError -eq $true) -or ($overflow -eq $true)) {
        $issues = New-Object 'System.Collections.Generic.List[string]'
        if ($writeError -eq $true) { $issues.Add('Recording Server cannot write GOP data to the media database') }
        if ($overflow -eq $true) { $issues.Add('Storage is not keeping up with incoming media') }
        return [pscustomobject][ordered]@{
            Status   = 'STORAGE ERROR'
            Severity = 30
            Online   = 'Yes'
            Issue    = ($issues -join '; ')
        }
    }

    if ($dbRepair -eq $true) {
        return [pscustomobject][ordered]@{
            Status   = 'DB REPAIR'
            Severity = 40
            Online   = 'Yes'
            Issue    = 'Recording Server is repairing the camera media database'
        }
    }

    if ($eventState -match '(?i)offline|not.?respond|connection.?lost|unavailable|stopped') {
        return [pscustomobject][ordered]@{
            Status   = 'NOT STARTED'
            Severity = 50
            Online   = 'No'
            Issue    = 'Event Server reports that the enabled camera is not responding or stopped'
        }
    }

    # A false value alone is not proof that a recorder status request succeeded;
    # some failed requests can leave default Boolean values behind. StatusTime,
    # a positive Started result, or a true fault flag proves status was returned.
    $hasRecorderStatus = ($null -ne $statusTime) -or ($started -eq $true) -or
                         ($noConnection -eq $true) -or ($notLicensed -eq $true) -or
                         ($writeError -eq $true) -or ($overflow -eq $true) -or
                         ($dbRepair -eq $true) -or ($genericError -eq $true)

    if (-not $hasRecorderStatus) {
        return [pscustomobject][ordered]@{
            Status   = 'UNKNOWN'
            Severity = 70
            Online   = 'Unknown'
            Issue    = 'Recorder-side status was unavailable; verify TCP 7563 to the Recording Server'
        }
    }

    if ($started -eq $false) {
        return [pscustomobject][ordered]@{
            Status   = 'NOT STARTED'
            Severity = 50
            Online   = 'No'
            Issue    = 'Camera is enabled but has not been started by the Recording Server'
        }
    }

    if ($genericError -eq $true) {
        return [pscustomobject][ordered]@{
            Status   = 'ERROR'
            Severity = 60
            Online   = 'Unknown'
            Issue    = 'Recording Server reports a device error'
        }
    }

    return [pscustomobject][ordered]@{
        Status   = 'ONLINE'
        Severity = 800
        Online   = 'Yes'
        Issue    = ''
    }
}

function Get-XpHardwareHealth {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        $Hardware,

        [Parameter()]
        [object[]]$CameraRows = @(),

        [Parameter()]
        [AllowNull()]
        $DirectStatus
    )

    $hardwareEnabled = ConvertTo-XpBool (Get-XpProperty -Object $Hardware -Name @('Enabled'))
    if ($hardwareEnabled -eq $false) {
        return [pscustomobject][ordered]@{
            Status       = 'DISABLED'
            Severity     = 900
            Online       = 'N/A'
            Issue        = 'Hardware is disabled in XProtect'
            StatusSource = 'Configuration'
        }
    }

    $enabledRows = @($CameraRows | Where-Object { $_.Enabled -eq $true })
    $onlineRows = @($enabledRows | Where-Object { $_.Status -eq 'ONLINE' })
    $offlineRows = @($enabledRows | Where-Object { $_.Status -in @('OFFLINE', 'NOT STARTED', 'UNLICENSED') })
    $problemRows = @($enabledRows | Where-Object { $_.Status -notin @('ONLINE', 'DISABLED') })
    $unknownRows = @($enabledRows | Where-Object { $_.Status -eq 'UNKNOWN' })

    if ($null -ne $DirectStatus) {
        $started = ConvertTo-XpBool (Get-XpProperty -Object $DirectStatus -Name @('IsStarted', 'Started'))
        $notLicensed = ConvertTo-XpBool (Get-XpProperty -Object $DirectStatus -Name @('ErrorNotLicensed'))
        $noConnection = ConvertTo-XpBool (Get-XpProperty -Object $DirectStatus -Name @('ErrorNoConnection'))
        $genericError = ConvertTo-XpBool (Get-XpProperty -Object $DirectStatus -Name @('Error'))
        $writeError = ConvertTo-XpBool (Get-XpProperty -Object $DirectStatus -Name @('ErrorWritingGOP', 'ErrorWritingGop'))
        $overflow = ConvertTo-XpBool (Get-XpProperty -Object $DirectStatus -Name @('IsInOverflow', 'ErrorOverflow'))

        if ($notLicensed -eq $true) {
            return [pscustomobject][ordered]@{
                Status       = 'UNLICENSED'
                Severity     = 10
                Online       = 'No'
                Issue        = 'Hardware is not licensed or its grace period has expired'
                StatusSource = 'Recorder hardware status'
            }
        }

        if ($noConnection -eq $true) {
            return [pscustomobject][ordered]@{
                Status       = 'OFFLINE'
                Severity     = 20
                Online       = 'No'
                Issue        = 'Recording Server cannot communicate with the hardware'
                StatusSource = 'Recorder hardware status'
            }
        }

        if (($writeError -eq $true) -or ($overflow -eq $true)) {
            return [pscustomobject][ordered]@{
                Status       = 'STORAGE ERROR'
                Severity     = 30
                Online       = 'Yes'
                Issue        = 'Recorder reports a storage write or overflow condition'
                StatusSource = 'Recorder hardware status'
            }
        }

        if (($started -eq $false) -or ($genericError -eq $true)) {
            return [pscustomobject][ordered]@{
                Status       = 'NOT STARTED'
                Severity     = 50
                Online       = 'No'
                Issue        = 'Hardware is enabled but the Recording Server has not started it successfully'
                StatusSource = 'Recorder hardware status'
            }
        }

        if ($started -eq $true) {
            if ($problemRows.Count -gt 0) {
                return [pscustomobject][ordered]@{
                    Status       = 'DEGRADED'
                    Severity     = 60
                    Online       = 'Yes'
                    Issue        = ('Hardware responds, but {0} enabled camera channel(s) have a problem' -f $problemRows.Count)
                    StatusSource = 'Recorder hardware status plus camera channels'
                }
            }

            return [pscustomobject][ordered]@{
                Status       = 'ONLINE'
                Severity     = 800
                Online       = 'Yes'
                Issue        = ''
                StatusSource = 'Recorder hardware status'
            }
        }
    }

    if ($enabledRows.Count -eq 0) {
        if ($CameraRows.Count -eq 0) {
            return [pscustomobject][ordered]@{
                Status       = 'UNKNOWN'
                Severity     = 70
                Online       = 'Unknown'
                Issue        = 'No camera channels or direct recorder hardware status were available'
                StatusSource = 'Configuration only'
            }
        }

        return [pscustomobject][ordered]@{
            Status       = 'NO ENABLED CAMERAS'
            Severity     = 850
            Online       = 'N/A'
            Issue        = 'Hardware is enabled, but all camera channels are disabled'
            StatusSource = 'Camera channel aggregate'
        }
    }

    if ($onlineRows.Count -eq $enabledRows.Count) {
        return [pscustomobject][ordered]@{
            Status       = 'ONLINE'
            Severity     = 800
            Online       = 'Yes'
            Issue        = ''
            StatusSource = 'Camera channel aggregate'
        }
    }

    if (($offlineRows.Count -eq $enabledRows.Count) -and ($enabledRows.Count -gt 0)) {
        return [pscustomobject][ordered]@{
            Status       = 'OFFLINE'
            Severity     = 20
            Online       = 'No'
            Issue        = 'Every enabled camera channel on this hardware is offline, unlicensed, or not started'
            StatusSource = 'Camera channel aggregate'
        }
    }

    if (($unknownRows.Count -eq $enabledRows.Count) -and ($enabledRows.Count -gt 0)) {
        return [pscustomobject][ordered]@{
            Status       = 'UNKNOWN'
            Severity     = 70
            Online       = 'Unknown'
            Issue        = 'Recorder-side status was unavailable for every enabled camera channel'
            StatusSource = 'Camera channel aggregate'
        }
    }

    return [pscustomobject][ordered]@{
        Status       = 'DEGRADED'
        Severity     = 60
        Online       = 'Partial'
        Issue        = ('{0} of {1} enabled camera channel(s) require attention' -f $problemRows.Count, $enabledRows.Count)
        StatusSource = 'Camera channel aggregate'
    }
}

function New-XpHtmlTable {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)]
        [object[]]$Items,

        [Parameter(Mandatory)]
        [object[]]$Columns,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [string]$Id
    )

    if ($Items.Count -eq 0) {
        return '<p class="empty">Nothing to show.</p>'
    }

    $builder = New-Object System.Text.StringBuilder
    [void]$builder.AppendLine(('<div class="table-wrap"><table class="data-table" id="{0}"><thead><tr>' -f (ConvertTo-XpHtmlText $Id)))

    foreach ($column in $Columns) {
        [void]$builder.AppendLine(('<th>{0}</th>' -f (ConvertTo-XpHtmlText (Get-XpProperty -Object $column -Name @('Label')))))
    }

    [void]$builder.AppendLine('</tr></thead><tbody>')

    foreach ($item in $Items) {
        $status = [string](Get-XpProperty -Object $item -Name @('Status') -Default 'UNKNOWN')
        $statusSlug = Get-XpStatusSlug -Status $status
        [void]$builder.AppendLine(('<tr class="row-{0}">' -f $statusSlug))

        foreach ($column in $Columns) {
            $propertyName = [string](Get-XpProperty -Object $column -Name @('Property'))
            $value = Get-XpProperty -Object $item -Name @($propertyName)

            if ($propertyName -eq 'Status') {
                [void]$builder.AppendLine(('<td><span class="badge badge-{0}">{1}</span></td>' -f $statusSlug, (ConvertTo-XpHtmlText $value)))
            }
            else {
                [void]$builder.AppendLine(('<td>{0}</td>' -f (ConvertTo-XpHtmlText $value)))
            }
        }

        [void]$builder.AppendLine('</tr>')
    }

    [void]$builder.AppendLine('</tbody></table></div>')
    return $builder.ToString()
}

if ($PSVersionTable.PSEdition -ne 'Desktop') {
    throw 'MilestonePSTools requires Windows PowerShell 5.1. Run this script using powershell.exe, not pwsh.exe.'
}

if ($ExecutionContext.SessionState.LanguageMode -ne 'FullLanguage') {
    throw ('PowerShell language mode is {0}. MilestonePSTools requires FullLanguage mode.' -f $ExecutionContext.SessionState.LanguageMode)
}

if ($BasicUser -and ($null -eq $ServerAddress)) {
    throw '-BasicUser can only be used with -ServerAddress and a Milestone basic-user credential.'
}

if ($BasicUser -and ($null -eq $Credential)) {
    throw '-BasicUser requires -Credential. Example: -Credential (Get-Credential) -BasicUser'
}

$module = Get-Module -Name MilestonePSTools -ListAvailable | Sort-Object Version -Descending | Select-Object -First 1
if ($null -eq $module) {
    if (-not $InstallModule) {
        throw "MilestonePSTools is not installed. Re-run with -InstallModule, or run: Install-Module MilestonePSTools -Scope CurrentUser"
    }

    Write-Host 'Installing MilestonePSTools for the current Windows user...' -ForegroundColor Cyan

    # Older Windows PowerShell builds commonly default to TLS 1.0, which the
    # PowerShell Gallery no longer accepts.
    [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

    if ($null -eq (Get-PackageProvider -Name NuGet -ListAvailable -ErrorAction SilentlyContinue)) {
        Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Scope CurrentUser -Force -Confirm:$false -ErrorAction Stop | Out-Null
    }

    Install-Module -Name MilestonePSTools -Scope CurrentUser -Force -AllowClobber -Confirm:$false -ErrorAction Stop
    $module = Get-Module -Name MilestonePSTools -ListAvailable | Sort-Object Version -Descending | Select-Object -First 1
}

Import-Module -Name MilestonePSTools -Force -ErrorAction Stop

if ($null -eq (Get-Command -Name Get-VmsCameraReport -ErrorAction SilentlyContinue)) {
    throw 'The installed MilestonePSTools version does not contain Get-VmsCameraReport. Run Update-Module MilestonePSTools.'
}

$moduleVersion = [string]$module.Version
Write-Host ("Using MilestonePSTools {0}" -f $moduleVersion) -ForegroundColor DarkCyan

$connectParameters = @{
    AcceptEula  = $true
    ErrorAction = 'Stop'
}

if ($null -ne $ServerAddress) {
    $connectParameters.ServerAddress = $ServerAddress
    if ($null -ne $Credential) { $connectParameters.Credential = $Credential }
    if ($BasicUser) { $connectParameters.BasicUser = $true }
    if ($SecureOnly) { $connectParameters.SecureOnly = $true }
}
else {
    $connectParameters.Name = $ConnectionProfile
}

Write-Host 'Connecting to XProtect...' -ForegroundColor Cyan
$managementServer = Connect-Vms @connectParameters

if ($null -eq $managementServer) {
    throw 'Connect-Vms did not return a Management Server object.'
}

$managementServerName = [string](Get-XpProperty -Object $managementServer -Name @('Name', 'Address', 'HostName') -Default $ServerAddress)
Write-Host ("Connected to {0}" -f $managementServerName) -ForegroundColor Green

$reportParameters = @{
    EnableFilter = 'All'
    ErrorAction  = 'Stop'
}
if ($IncludeRetentionInfo) { $reportParameters.IncludeRetentionInfo = $true }
if ($IncludeRecordingStats) { $reportParameters.IncludeRecordingStats = $true }

Write-Host 'Collecting recording servers and hardware...' -ForegroundColor Cyan
$recordingServers = @(Get-VmsRecordingServer -ErrorAction Stop)
$hardwareItems = @(Get-VmsHardware -EnableFilter All -ErrorAction Stop)

Write-Host 'Collecting detailed camera configuration and live recorder status...' -ForegroundColor Cyan
$rawCameraReportList = New-Object 'System.Collections.Generic.List[object]'
$cameraReportFailures = New-Object 'System.Collections.Generic.List[object]'

if ($recordingServers.Count -gt 0) {
    foreach ($recordingServer in $recordingServers) {
        $recorderDisplayName = [string](Get-XpProperty -Object $recordingServer -Name @('Name', 'HostName', 'Address') -Default 'Unknown Recording Server')
        Write-Host ("  Querying {0}" -f $recorderDisplayName) -ForegroundColor DarkCyan

        $recorderReportParameters = @{}
        foreach ($key in $reportParameters.Keys) {
            $recorderReportParameters[$key] = $reportParameters[$key]
        }
        $recorderReportParameters.RecordingServer = @($recordingServer)

        try {
            $recorderCameraRows = @(Get-VmsCameraReport @recorderReportParameters)
            foreach ($recorderCameraRow in $recorderCameraRows) {
                $rawCameraReportList.Add($recorderCameraRow)
            }
        }
        catch {
            $failure = [pscustomobject][ordered]@{
                RecordingServer = $recorderDisplayName
                RecorderId      = Get-XpProperty -Object $recordingServer -Name @('Id', 'RecorderId')
                Error           = $_.Exception.Message
                Object          = $recordingServer
            }
            $cameraReportFailures.Add($failure)
            Write-Warning ("Camera report failed for {0}. A configuration-only fallback will be attempted. {1}" -f $recorderDisplayName, $_.Exception.Message)
        }
    }
}
else {
    try {
        foreach ($cameraReportRow in @(Get-VmsCameraReport @reportParameters)) {
            $rawCameraReportList.Add($cameraReportRow)
        }
    }
    catch {
        throw ("Camera report failed and no Recording Server list was available for fallback. {0}" -f $_.Exception.Message)
    }
}

# If a Recording Server rejected the detailed report, retain configuration-only
# inventory for its cameras. These rows deliberately classify as UNKNOWN rather
# than falsely claiming the cameras are online.
foreach ($failure in $cameraReportFailures) {
    $failedRecorder = $failure.Object
    $failedRecorderName = $failure.RecordingServer
    $failedRecorderId = $failure.RecorderId

    try {
        $failedHardware = @(Get-VmsHardware -RecordingServer $failedRecorder -EnableFilter All -ErrorAction Stop)
        foreach ($failedHardwareItem in $failedHardware) {
            $fallbackCameras = @($failedHardwareItem | Get-VmsCamera -EnableFilter All -ErrorAction Stop)
            foreach ($fallbackCamera in $fallbackCameras) {
                $fallbackRow = [pscustomobject][ordered]@{
                    Name             = Get-XpProperty -Object $fallbackCamera -Name @('Name')
                    Channel          = Get-XpProperty -Object $fallbackCamera -Name @('Channel')
                    Enabled          = ConvertTo-XpBool (Get-XpProperty -Object $fallbackCamera -Name @('Enabled'))
                    State            = $null
                    LastModified     = Get-XpProperty -Object $fallbackCamera -Name @('LastModified')
                    Id               = Get-XpProperty -Object $fallbackCamera -Name @('Id')
                    IsStarted        = $null
                    IsRecording      = $null
                    IsInOverflow     = $null
                    IsInDbRepair     = $null
                    ErrorWritingGOP  = $null
                    ErrorNotLicensed = $null
                    ErrorNoConnection = $null
                    StatusTime       = $null
                    HardwareName     = Get-XpProperty -Object $failedHardwareItem -Name @('Name')
                    HardwareId       = Get-XpProperty -Object $failedHardwareItem -Name @('Id', 'HardwareId')
                    Model            = $null
                    Address          = Get-XpProperty -Object $failedHardwareItem -Name @('Address')
                    Username         = $null
                    HTTPSEnabled     = $null
                    MAC              = $null
                    Firmware         = $null
                    DriverFamily     = $null
                    Driver           = $null
                    DriverNumber     = $null
                    DriverVersion    = $null
                    DriverRevision   = $null
                    RecorderName     = $failedRecorderName
                    RecorderUri      = Get-XpProperty -Object $failedRecorder -Name @('Address', 'Uri')
                    RecorderId       = $failedRecorderId
                    RecordingEnabled = $null
                    RecordingStorageName = $null
                    RecordingPath    = $null
                }
                $rawCameraReportList.Add($fallbackRow)
            }
        }
    }
    catch {
        Write-Warning ("Configuration-only camera fallback also failed for {0}. {1}" -f $failedRecorderName, $_.Exception.Message)
    }
}

$rawCameraReport = @($rawCameraReportList)

if (($hardwareItems.Count -eq 0) -and ($rawCameraReport.Count -eq 0)) {
    throw 'XProtect returned no hardware and no cameras. Check permissions and the connected site.'
}

$directHardwareStatusById = @{}
if ($null -ne (Get-Command -Name Get-CurrentDeviceStatus -ErrorAction SilentlyContinue)) {
    try {
        Write-Host 'Collecting direct hardware status from Recording Servers...' -ForegroundColor Cyan
        $directHardwareStatuses = @(Get-CurrentDeviceStatus -DeviceType Hardware -ErrorAction Stop)
        foreach ($hardwareStatus in $directHardwareStatuses) {
            $statusId = Get-XpKey (Get-XpProperty -Object $hardwareStatus -Name @('DeviceId', 'HardwareId', 'Id'))
            if (-not [string]::IsNullOrWhiteSpace($statusId)) {
                $directHardwareStatusById[$statusId] = $hardwareStatus
            }
        }
    }
    catch {
        Write-Warning ('Direct hardware status could not be collected. Hardware status will be derived from camera channels. {0}' -f $_.Exception.Message)
    }
}

$recordingServerById = @{}
foreach ($recordingServer in $recordingServers) {
    $recordingServerId = Get-XpKey (Get-XpProperty -Object $recordingServer -Name @('Id', 'RecorderId'))
    if (-not [string]::IsNullOrWhiteSpace($recordingServerId)) {
        $recordingServerById[$recordingServerId] = $recordingServer
    }
}

$hardwareById = @{}
foreach ($hardwareItem in $hardwareItems) {
    $hardwareId = Get-XpKey (Get-XpProperty -Object $hardwareItem -Name @('Id', 'HardwareId'))
    if (-not [string]::IsNullOrWhiteSpace($hardwareId)) {
        $hardwareById[$hardwareId] = $hardwareItem
    }
}

$cameraRows = New-Object 'System.Collections.Generic.List[object]'
foreach ($camera in $rawCameraReport) {
    $health = Get-XpCameraHealth -Camera $camera
    $hardwareId = Get-XpKey (Get-XpProperty -Object $camera -Name @('HardwareId'))
    $hardwareObject = $null
    if ($hardwareById.ContainsKey($hardwareId)) {
        $hardwareObject = $hardwareById[$hardwareId]
    }

    $hardwareEnabled = ConvertTo-XpBool (Get-XpProperty -Object $hardwareObject -Name @('Enabled'))
    $cameraEnabledCombined = ConvertTo-XpBool (Get-XpProperty -Object $camera -Name @('Enabled'))

    $cameraRow = [pscustomobject][ordered]@{
        Status                       = $health.Status
        Severity                     = $health.Severity
        Online                       = $health.Online
        Issue                        = $health.Issue
        CameraName                   = Get-XpProperty -Object $camera -Name @('Name')
        Channel                      = Get-XpProperty -Object $camera -Name @('Channel')
        Enabled                      = $cameraEnabledCombined
        HardwareEnabled              = $hardwareEnabled
        CameraId                     = Get-XpProperty -Object $camera -Name @('Id')
        EventServerState             = Get-XpProperty -Object $camera -Name @('State')
        IsStarted                    = ConvertTo-XpBool (Get-XpProperty -Object $camera -Name @('IsStarted'))
        IsRecording                  = ConvertTo-XpBool (Get-XpProperty -Object $camera -Name @('IsRecording'))
        RecordingEnabled             = ConvertTo-XpBool (Get-XpProperty -Object $camera -Name @('RecordingEnabled'))
        ErrorNoConnection            = ConvertTo-XpBool (Get-XpProperty -Object $camera -Name @('ErrorNoConnection'))
        ErrorNotLicensed             = ConvertTo-XpBool (Get-XpProperty -Object $camera -Name @('ErrorNotLicensed'))
        ErrorWritingGOP              = ConvertTo-XpBool (Get-XpProperty -Object $camera -Name @('ErrorWritingGOP'))
        IsInOverflow                 = ConvertTo-XpBool (Get-XpProperty -Object $camera -Name @('IsInOverflow'))
        IsInDbRepair                 = ConvertTo-XpBool (Get-XpProperty -Object $camera -Name @('IsInDbRepair'))
        StatusTime                   = Get-XpProperty -Object $camera -Name @('StatusTime')
        LastModified                 = Get-XpProperty -Object $camera -Name @('LastModified')
        HardwareName                 = Get-XpProperty -Object $camera -Name @('HardwareName')
        HardwareId                   = Get-XpProperty -Object $camera -Name @('HardwareId')
        Model                        = Get-XpProperty -Object $camera -Name @('Model')
        Firmware                     = Get-XpProperty -Object $camera -Name @('Firmware')
        Address                      = Get-XpProperty -Object $camera -Name @('Address')
        Username                     = Get-XpProperty -Object $camera -Name @('Username')
        HTTPSEnabled                 = ConvertTo-XpBool (Get-XpProperty -Object $camera -Name @('HTTPSEnabled'))
        MAC                          = Get-XpProperty -Object $camera -Name @('MAC')
        DriverFamily                 = Get-XpProperty -Object $camera -Name @('DriverFamily')
        Driver                       = Get-XpProperty -Object $camera -Name @('Driver')
        DriverNumber                 = Get-XpProperty -Object $camera -Name @('DriverNumber')
        DriverVersion                = Get-XpProperty -Object $camera -Name @('DriverVersion')
        DriverRevision               = Get-XpProperty -Object $camera -Name @('DriverRevision')
        RecordingServer              = Get-XpProperty -Object $camera -Name @('RecorderName')
        RecorderUri                  = Get-XpProperty -Object $camera -Name @('RecorderUri')
        RecorderId                   = Get-XpProperty -Object $camera -Name @('RecorderId')
        ConfiguredLiveResolution     = Get-XpProperty -Object $camera -Name @('ConfiguredLiveResolution')
        ConfiguredLiveCodec          = Get-XpProperty -Object $camera -Name @('ConfiguredLiveCodec')
        ConfiguredLiveFPS            = Get-XpProperty -Object $camera -Name @('ConfiguredLiveFPS')
        CurrentLiveResolution        = Get-XpProperty -Object $camera -Name @('CurrentLiveResolution')
        CurrentLiveCodec             = Get-XpProperty -Object $camera -Name @('CurrentLiveCodec')
        CurrentLiveFPS               = Get-XpProperty -Object $camera -Name @('CurrentLiveFPS')
        CurrentLiveBitrate           = Get-XpProperty -Object $camera -Name @('CurrentLiveBitrate')
        ConfiguredRecordedResolution = Get-XpProperty -Object $camera -Name @('ConfiguredRecordedResolution')
        ConfiguredRecordedCodec      = Get-XpProperty -Object $camera -Name @('ConfiguredRecordedCodec')
        ConfiguredRecordedFPS        = Get-XpProperty -Object $camera -Name @('ConfiguredRecordedFPS')
        CurrentRecordedResolution    = Get-XpProperty -Object $camera -Name @('CurrentRecordedResolution')
        CurrentRecordedCodec         = Get-XpProperty -Object $camera -Name @('CurrentRecordedCodec')
        CurrentRecordedFPS           = Get-XpProperty -Object $camera -Name @('CurrentRecordedFPS')
        CurrentRecordedBitrate       = Get-XpProperty -Object $camera -Name @('CurrentRecordedBitrate')
        RecordingStorageName         = Get-XpProperty -Object $camera -Name @('RecordingStorageName')
        RecordingPath                = Get-XpProperty -Object $camera -Name @('RecordingPath')
        ExpectedRetentionDays        = Get-XpProperty -Object $camera -Name @('ExpectedRetentionDays')
        ActualRetentionDays          = Get-XpProperty -Object $camera -Name @('ActualRetentionDays')
        MeetsRetentionPolicy         = Get-XpProperty -Object $camera -Name @('MeetsRetentionPolicy')
        UsedSpaceInGB                = Get-XpProperty -Object $camera -Name @('UsedSpaceInGB')
        PercentRecordedOneWeek       = Get-XpProperty -Object $camera -Name @('PercentRecordedOneWeek')
        MediaDatabaseBegin           = Get-XpProperty -Object $camera -Name @('MediaDatabaseBegin')
        MediaDatabaseEnd             = Get-XpProperty -Object $camera -Name @('MediaDatabaseEnd')
    }

    $cameraRows.Add($cameraRow)
}

$cameraRowsByHardwareId = @{}
foreach ($cameraRow in $cameraRows) {
    $cameraHardwareId = Get-XpKey $cameraRow.HardwareId
    if (-not $cameraRowsByHardwareId.ContainsKey($cameraHardwareId)) {
        $cameraRowsByHardwareId[$cameraHardwareId] = New-Object 'System.Collections.Generic.List[object]'
    }
    $cameraRowsByHardwareId[$cameraHardwareId].Add($cameraRow)
}

$hardwareRows = New-Object 'System.Collections.Generic.List[object]'
foreach ($hardwareItem in $hardwareItems) {
    $hardwareIdValue = Get-XpProperty -Object $hardwareItem -Name @('Id', 'HardwareId')
    $hardwareIdKey = Get-XpKey $hardwareIdValue
    $childCameraRows = @()
    if ($cameraRowsByHardwareId.ContainsKey($hardwareIdKey)) {
        $childCameraRows = @($cameraRowsByHardwareId[$hardwareIdKey])
    }

    $directHardwareStatus = $null
    if ($directHardwareStatusById.ContainsKey($hardwareIdKey)) {
        $directHardwareStatus = $directHardwareStatusById[$hardwareIdKey]
    }

    $hardwareHealth = Get-XpHardwareHealth -Hardware $hardwareItem -CameraRows $childCameraRows -DirectStatus $directHardwareStatus
    $firstCamera = $childCameraRows | Select-Object -First 1

    $hardwareSettings = $null
    $needsHardwareSettings = ($null -eq $firstCamera) -or
                             [string]::IsNullOrWhiteSpace([string](Get-XpProperty -Object $firstCamera -Name @('MAC'))) -or
                             [string]::IsNullOrWhiteSpace([string](Get-XpProperty -Object $firstCamera -Name @('Model'))) -or
                             [string]::IsNullOrWhiteSpace([string](Get-XpProperty -Object $firstCamera -Name @('Firmware')))
    if ($needsHardwareSettings -and ($null -ne (Get-Command -Name Get-HardwareSetting -ErrorAction SilentlyContinue))) {
        try {
            $hardwareSettings = $hardwareItem | Get-HardwareSetting -ErrorAction Stop
        }
        catch {
            $hardwareSettings = $null
        }
    }

    $recorderIdValue = Get-XpProperty -Object $hardwareItem -Name @('RecorderId', 'RecordingServerId')
    if ($null -eq $recorderIdValue) {
        $recorderIdValue = Get-XpProperty -Object $firstCamera -Name @('RecorderId')
    }
    $recorderName = Get-XpProperty -Object $firstCamera -Name @('RecordingServer')
    if ([string]::IsNullOrWhiteSpace([string]$recorderName)) {
        $recorderIdKey = Get-XpKey $recorderIdValue
        if ($recordingServerById.ContainsKey($recorderIdKey)) {
            $recorderName = Get-XpProperty -Object $recordingServerById[$recorderIdKey] -Name @('Name')
        }
    }

    $enabledChildCameras = @($childCameraRows | Where-Object { $_.Enabled -eq $true })
    $onlineChildCameras = @($enabledChildCameras | Where-Object { $_.Status -eq 'ONLINE' })
    $offlineChildCameras = @($enabledChildCameras | Where-Object { $_.Status -in @('OFFLINE', 'NOT STARTED', 'UNLICENSED') })
    $problemChildCameras = @($enabledChildCameras | Where-Object { $_.Status -notin @('ONLINE', 'DISABLED') })
    $unknownChildCameras = @($enabledChildCameras | Where-Object { $_.Status -eq 'UNKNOWN' })

    $hardwareRow = [pscustomobject][ordered]@{
        Status                   = $hardwareHealth.Status
        Severity                 = $hardwareHealth.Severity
        Online                   = $hardwareHealth.Online
        Issue                    = $hardwareHealth.Issue
        StatusSource             = $hardwareHealth.StatusSource
        HardwareName             = Get-XpProperty -Object $hardwareItem -Name @('Name')
        Enabled                  = ConvertTo-XpBool (Get-XpProperty -Object $hardwareItem -Name @('Enabled'))
        HardwareId               = $hardwareIdValue
        Address                  = Get-XpProperty -Object $hardwareItem -Name @('Address') -Default (Get-XpProperty -Object $firstCamera -Name @('Address'))
        MAC                      = Get-XpProperty -Object $firstCamera -Name @('MAC') -Default (Get-XpProperty -Object $hardwareSettings -Name @('MACAddress', 'MAC'))
        Model                    = Get-XpProperty -Object $firstCamera -Name @('Model') -Default (Get-XpProperty -Object $hardwareSettings -Name @('Model', 'ModelName'))
        Firmware                 = Get-XpProperty -Object $firstCamera -Name @('Firmware') -Default (Get-XpProperty -Object $hardwareSettings -Name @('Firmware', 'FirmwareVersion'))
        HTTPSEnabled             = Get-XpProperty -Object $firstCamera -Name @('HTTPSEnabled')
        DriverFamily             = Get-XpProperty -Object $firstCamera -Name @('DriverFamily')
        Driver                   = Get-XpProperty -Object $firstCamera -Name @('Driver')
        DriverNumber             = Get-XpProperty -Object $firstCamera -Name @('DriverNumber')
        DriverVersion            = Get-XpProperty -Object $firstCamera -Name @('DriverVersion')
        RecordingServer          = $recorderName
        RecorderId               = $recorderIdValue
        CameraChannels           = $childCameraRows.Count
        EnabledCameraChannels    = $enabledChildCameras.Count
        OnlineCameraChannels     = $onlineChildCameras.Count
        OfflineCameraChannels    = $offlineChildCameras.Count
        ProblemCameraChannels    = $problemChildCameras.Count
        UnknownCameraChannels    = $unknownChildCameras.Count
        RecorderHardwareStarted  = ConvertTo-XpBool (Get-XpProperty -Object $directHardwareStatus -Name @('IsStarted', 'Started'))
        ErrorNoConnection        = ConvertTo-XpBool (Get-XpProperty -Object $directHardwareStatus -Name @('ErrorNoConnection'))
        ErrorNotLicensed         = ConvertTo-XpBool (Get-XpProperty -Object $directHardwareStatus -Name @('ErrorNotLicensed'))
        RecorderHardwareStatusAt = Get-XpProperty -Object $directHardwareStatus -Name @('StatusTime', 'Time')
    }

    $hardwareRows.Add($hardwareRow)
}

$sortedCameraRows = @($cameraRows | Sort-Object Severity, RecordingServer, HardwareName, Channel, CameraName)
$sortedHardwareRows = @($hardwareRows | Sort-Object Severity, RecordingServer, HardwareName)

$timestamp = Get-Date
$runFolder = Join-Path -Path $OutputPath -ChildPath ('XProtect-Health-{0}' -f $timestamp.ToString('yyyyMMdd-HHmmss'))
$null = New-Item -ItemType Directory -Path $runFolder -Force

$cameraStatusCsv = Join-Path $runFolder 'XProtect-Camera-Status.csv'
$hardwareStatusCsv = Join-Path $runFolder 'XProtect-Hardware-Status.csv'
$fullInventoryCsv = Join-Path $runFolder 'XProtect-Camera-Inventory-Full.csv'
$htmlReportPath = Join-Path $runFolder 'XProtect-Health-Report.html'
$summaryJsonPath = Join-Path $runFolder 'XProtect-Run-Summary.json'

$sortedCameraRows | Export-Csv -Path $cameraStatusCsv -NoTypeInformation -Encoding UTF8
$sortedHardwareRows | Export-Csv -Path $hardwareStatusCsv -NoTypeInformation -Encoding UTF8
$rawCameraReport | Export-Csv -Path $fullInventoryCsv -NoTypeInformation -Encoding UTF8

$cameraTotal = $sortedCameraRows.Count
$cameraOnline = @($sortedCameraRows | Where-Object { $_.Status -eq 'ONLINE' }).Count
$cameraOffline = @($sortedCameraRows | Where-Object { $_.Status -eq 'OFFLINE' }).Count
$cameraDisabled = @($sortedCameraRows | Where-Object { $_.Status -eq 'DISABLED' }).Count
$cameraUnknown = @($sortedCameraRows | Where-Object { $_.Status -eq 'UNKNOWN' }).Count
$cameraAttention = @($sortedCameraRows | Where-Object { $_.Status -notin @('ONLINE', 'DISABLED') }).Count

$hardwareTotal = $sortedHardwareRows.Count
$hardwareOnline = @($sortedHardwareRows | Where-Object { $_.Status -eq 'ONLINE' }).Count
$hardwareOffline = @($sortedHardwareRows | Where-Object { $_.Status -eq 'OFFLINE' }).Count
$hardwareDisabled = @($sortedHardwareRows | Where-Object { $_.Status -eq 'DISABLED' }).Count
$hardwareUnknown = @($sortedHardwareRows | Where-Object { $_.Status -eq 'UNKNOWN' }).Count
$hardwareAttention = @($sortedHardwareRows | Where-Object { $_.Status -notin @('ONLINE', 'DISABLED', 'NO ENABLED CAMERAS') }).Count

$attentionCameraRows = @($sortedCameraRows | Where-Object { $_.Status -notin @('ONLINE', 'DISABLED') })

$hardwareColumns = @(
    [pscustomobject]@{ Label = 'Status'; Property = 'Status' }
    [pscustomobject]@{ Label = 'Hardware'; Property = 'HardwareName' }
    [pscustomobject]@{ Label = 'Address'; Property = 'Address' }
    [pscustomobject]@{ Label = 'Model'; Property = 'Model' }
    [pscustomobject]@{ Label = 'Firmware'; Property = 'Firmware' }
    [pscustomobject]@{ Label = 'MAC'; Property = 'MAC' }
    [pscustomobject]@{ Label = 'Recording Server'; Property = 'RecordingServer' }
    [pscustomobject]@{ Label = 'Cameras'; Property = 'CameraChannels' }
    [pscustomobject]@{ Label = 'Online'; Property = 'OnlineCameraChannels' }
    [pscustomobject]@{ Label = 'Problems'; Property = 'ProblemCameraChannels' }
    [pscustomobject]@{ Label = 'Issue'; Property = 'Issue' }
)

$cameraAttentionColumns = @(
    [pscustomobject]@{ Label = 'Status'; Property = 'Status' }
    [pscustomobject]@{ Label = 'Camera'; Property = 'CameraName' }
    [pscustomobject]@{ Label = 'Hardware'; Property = 'HardwareName' }
    [pscustomobject]@{ Label = 'Address'; Property = 'Address' }
    [pscustomobject]@{ Label = 'Recording Server'; Property = 'RecordingServer' }
    [pscustomobject]@{ Label = 'State'; Property = 'EventServerState' }
    [pscustomobject]@{ Label = 'Started'; Property = 'IsStarted' }
    [pscustomobject]@{ Label = 'Last Status'; Property = 'StatusTime' }
    [pscustomobject]@{ Label = 'Issue'; Property = 'Issue' }
)

$cameraColumns = @(
    [pscustomobject]@{ Label = 'Status'; Property = 'Status' }
    [pscustomobject]@{ Label = 'Camera'; Property = 'CameraName' }
    [pscustomobject]@{ Label = 'Channel'; Property = 'Channel' }
    [pscustomobject]@{ Label = 'Hardware'; Property = 'HardwareName' }
    [pscustomobject]@{ Label = 'Address'; Property = 'Address' }
    [pscustomobject]@{ Label = 'Model'; Property = 'Model' }
    [pscustomobject]@{ Label = 'Firmware'; Property = 'Firmware' }
    [pscustomobject]@{ Label = 'Recording Server'; Property = 'RecordingServer' }
    [pscustomobject]@{ Label = 'Live'; Property = 'CurrentLiveResolution' }
    [pscustomobject]@{ Label = 'Live FPS'; Property = 'CurrentLiveFPS' }
    [pscustomobject]@{ Label = 'Recording'; Property = 'CurrentRecordedResolution' }
    [pscustomobject]@{ Label = 'Rec FPS'; Property = 'CurrentRecordedFPS' }
    [pscustomobject]@{ Label = 'Storage'; Property = 'RecordingStorageName' }
    [pscustomobject]@{ Label = 'Last Status'; Property = 'StatusTime' }
    [pscustomobject]@{ Label = 'Issue'; Property = 'Issue' }
)

$hardwareTable = New-XpHtmlTable -Items $sortedHardwareRows -Columns $hardwareColumns -Id 'hardware-table'
$attentionTable = New-XpHtmlTable -Items $attentionCameraRows -Columns $cameraAttentionColumns -Id 'attention-table'
$cameraTable = New-XpHtmlTable -Items $sortedCameraRows -Columns $cameraColumns -Id 'camera-table'

$css = @'
:root {
    color-scheme: dark;
    --bg: #0d0f12;
    --panel: #171a1f;
    --panel-2: #20242b;
    --text: #f3f4f6;
    --muted: #a5acb8;
    --line: #343a44;
    --red: #ed1c24;
    --green: #2dbf6f;
    --amber: #f1aa2b;
    --grey: #77808e;
}
* { box-sizing: border-box; }
body {
    margin: 0;
    font-family: "Segoe UI", Arial, sans-serif;
    background: var(--bg);
    color: var(--text);
}
header {
    padding: 28px 36px;
    border-bottom: 3px solid var(--red);
    background: linear-gradient(135deg, #111318, #1a1d23);
}
h1 { margin: 0 0 6px; font-size: 30px; letter-spacing: .2px; }
header p { margin: 4px 0; color: var(--muted); }
main { padding: 24px 36px 50px; }
.cards {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
    gap: 12px;
    margin: 0 0 24px;
}
.card {
    padding: 16px;
    background: var(--panel);
    border: 1px solid var(--line);
    border-top: 3px solid var(--red);
    border-radius: 6px;
}
.card strong { display: block; font-size: 26px; margin-bottom: 3px; }
.card span { color: var(--muted); font-size: 13px; }
section {
    background: var(--panel);
    border: 1px solid var(--line);
    border-radius: 7px;
    padding: 18px;
    margin: 0 0 22px;
}
h2 { margin: 0 0 12px; font-size: 20px; }
.note {
    border-left: 4px solid var(--amber);
    background: #222019;
    padding: 11px 14px;
    margin: 0 0 18px;
    color: #e9dfc5;
}
.search {
    width: min(520px, 100%);
    margin: 0 0 14px;
    padding: 10px 12px;
    color: var(--text);
    background: var(--panel-2);
    border: 1px solid var(--line);
    border-radius: 5px;
}
.table-wrap { width: 100%; overflow-x: auto; }
table { width: 100%; border-collapse: collapse; font-size: 12px; }
th {
    text-align: left;
    white-space: nowrap;
    position: sticky;
    top: 0;
    background: #252a31;
    color: #fff;
    border-bottom: 2px solid #555d69;
    padding: 9px 8px;
}
td {
    vertical-align: top;
    border-bottom: 1px solid #303640;
    padding: 8px;
    max-width: 360px;
    overflow-wrap: anywhere;
}
tr:hover td { background: rgba(255,255,255,.035); }
.row-offline td, .row-unlicensed td, .row-storage-error td { background: rgba(237, 28, 36, .09); }
.row-not-started td, .row-degraded td, .row-error td, .row-db-repair td { background: rgba(241, 170, 43, .08); }
.row-unknown td { background: rgba(119, 128, 142, .08); }
.row-disabled td, .row-no-enabled-cameras td { color: #9299a5; }
.badge {
    display: inline-block;
    padding: 3px 7px;
    border-radius: 999px;
    font-size: 10px;
    font-weight: 700;
    white-space: nowrap;
    background: #3a414c;
}
.badge-online { background: #155b39; color: #d9ffea; }
.badge-offline, .badge-unlicensed, .badge-storage-error { background: #7a1c22; color: #ffe0e2; }
.badge-not-started, .badge-degraded, .badge-error, .badge-db-repair { background: #795719; color: #fff0c8; }
.badge-unknown { background: #48505c; color: #f1f3f6; }
.badge-disabled, .badge-no-enabled-cameras { background: #30343b; color: #b8bec8; }
.empty { color: var(--muted); font-style: italic; }
footer { color: var(--muted); font-size: 12px; padding-top: 8px; }
@media print {
    body { color-scheme: light; background: #fff; color: #111; }
    header, section, .card { background: #fff; color: #111; }
    .search { display: none; }
    th { position: static; background: #eee; color: #111; }
}
'@

$javascript = @'
function filterTables() {
    const input = document.getElementById('global-search');
    const query = input.value.toLowerCase().trim();
    document.querySelectorAll('table.data-table tbody tr').forEach(function(row) {
        row.style.display = row.innerText.toLowerCase().includes(query) ? '' : 'none';
    });
}
'@

$html = @"
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>XProtect Health Report - $(ConvertTo-XpHtmlText $managementServerName)</title>
<style>$css</style>
</head>
<body>
<header>
    <h1>XProtect Hardware &amp; Camera Health</h1>
    <p><strong>Site:</strong> $(ConvertTo-XpHtmlText $managementServerName)</p>
    <p><strong>Generated:</strong> $(ConvertTo-XpHtmlText $timestamp) &nbsp; | &nbsp; <strong>MilestonePSTools:</strong> $(ConvertTo-XpHtmlText $moduleVersion)</p>
</header>
<main>
    <div class="cards">
        <div class="card"><strong>$cameraTotal</strong><span>Total cameras</span></div>
        <div class="card"><strong>$cameraOnline</strong><span>Cameras online</span></div>
        <div class="card"><strong>$cameraOffline</strong><span>Cameras offline</span></div>
        <div class="card"><strong>$cameraAttention</strong><span>Cameras requiring attention</span></div>
        <div class="card"><strong>$hardwareTotal</strong><span>Total hardware</span></div>
        <div class="card"><strong>$hardwareOnline</strong><span>Hardware online</span></div>
        <div class="card"><strong>$hardwareOffline</strong><span>Hardware offline</span></div>
        <div class="card"><strong>$hardwareAttention</strong><span>Hardware requiring attention</span></div>
    </div>

    <div class="note">
        Online/offline is based primarily on the Recording Server status service, not ICMP ping. UNKNOWN usually means this computer could not obtain recorder-side status; confirm TCP 7563 from this computer to the relevant Recording Server. IsRecording is shown in CSV but is not treated as an outage because motion and schedule-based recording can legitimately be idle.
    </div>

    <input id="global-search" class="search" type="search" placeholder="Filter every table by camera, address, recorder, status..." oninput="filterTables()">

    <section>
        <h2>Camera Action List ($cameraAttention)</h2>
        $attentionTable
    </section>

    <section>
        <h2>Hardware Summary ($hardwareTotal)</h2>
        $hardwareTable
    </section>

    <section>
        <h2>All Cameras ($cameraTotal)</h2>
        $cameraTable
    </section>

    <footer>
        Disabled cameras: $cameraDisabled | Unknown camera status: $cameraUnknown | Disabled hardware: $hardwareDisabled | Unknown hardware status: $hardwareUnknown<br>
        Detailed configuration, status flags, storage, stream and optional retention fields are available in the CSV files generated beside this report.
    </footer>
</main>
<script>$javascript</script>
</body>
</html>
"@

Set-Content -Path $htmlReportPath -Value $html -Encoding UTF8

$runSummary = [pscustomobject][ordered]@{
    GeneratedAt                = $timestamp
    ManagementServer          = $managementServerName
    MilestonePSToolsVersion    = $moduleVersion
    IncludeRetentionInfo       = [bool]$IncludeRetentionInfo
    IncludeRecordingStats      = [bool]$IncludeRecordingStats
    RecordingServers           = $recordingServers.Count
    CameraReportFailures       = $cameraReportFailures.Count
    HardwareTotal              = $hardwareTotal
    HardwareOnline             = $hardwareOnline
    HardwareOffline            = $hardwareOffline
    HardwareAttention          = $hardwareAttention
    HardwareDisabled           = $hardwareDisabled
    HardwareUnknown            = $hardwareUnknown
    CamerasTotal               = $cameraTotal
    CamerasOnline              = $cameraOnline
    CamerasOffline             = $cameraOffline
    CamerasAttention           = $cameraAttention
    CamerasDisabled            = $cameraDisabled
    CamerasUnknown             = $cameraUnknown
    OutputFolder               = $runFolder
    HtmlReport                 = $htmlReportPath
    CameraStatusCsv            = $cameraStatusCsv
    HardwareStatusCsv          = $hardwareStatusCsv
    FullCameraInventoryCsv     = $fullInventoryCsv
}

$runSummary | ConvertTo-Json -Depth 4 | Set-Content -Path $summaryJsonPath -Encoding UTF8

Write-Host ''
Write-Host 'XProtect health report complete.' -ForegroundColor Green
Write-Host ("  Cameras : {0} total | {1} online | {2} offline | {3} attention" -f $cameraTotal, $cameraOnline, $cameraOffline, $cameraAttention)
Write-Host ("  Hardware: {0} total | {1} online | {2} offline | {3} attention" -f $hardwareTotal, $hardwareOnline, $hardwareOffline, $hardwareAttention)
Write-Host ("  Report  : {0}" -f $htmlReportPath) -ForegroundColor Cyan

if ($OpenReport) {
    Start-Process -FilePath $htmlReportPath
}

[pscustomobject][ordered]@{
    OutputFolder           = $runFolder
    HtmlReport             = $htmlReportPath
    CameraStatusCsv        = $cameraStatusCsv
    HardwareStatusCsv      = $hardwareStatusCsv
    FullCameraInventoryCsv = $fullInventoryCsv
    SummaryJson            = $summaryJsonPath
}
